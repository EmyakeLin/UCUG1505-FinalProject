# Prototype A · Reference-led revision 5

Built in Blender 4.3.2 from the user's latest image, columns 02/03/04 only. Column 01 is ignored; the accepted tall monolith is unchanged.

## Scale and actual geometry
D = 1 scene unit. The user approved reference shape priority over previous overall sizes and flush-ground requirements. The building sizes were increased to preserve both the illustrated proportions and usable clear openings; D itself was not redefined.

- `building_arch_v03.glb`: 5.890 × 2.170 × 4.030D (Blender X/Y/Z).
- `building_bowl_v02.glb`: 7.000 × 7.000 × 1.430D (Blender X/Y/Z).
- `building_bowl_v02_display.glb`: 7.000 × 7.000 × 1.430D (Blender X/Y/Z).
- `building_monolith_v06.glb`: 3.000 × 3.000 × 5.012D (Blender X/Y/Z).
- `building_nest_v03.glb`: 5.220 × 4.640 × 1.900D (Blender X/Y/Z).
- `energy_mote.glb`: 0.700 × 0.700 × 0.700D (Blender X/Y/Z).

Nest: thicker green/cream rounded wall, narrower inward-turning entrance, two separate pads, visible 0.16D raised platform. Sampled entrance clearance 1.353D. Bowl: short rear rim and two long side rims, a visible 0.18D platform, three gaps with sampled clear diameters of 1.419D. Arch: left-low/right-high rounded shoulder, aligned cream bases, 2.047D minimum overhead across a 2.48D-wide central region. Static mesh samples are not a runtime physics guarantee.

## Files and use
- `source/Prototype_A_buildings.blend`: editable meshes, materials and UVs. Four groups are arranged side by side; root empty positions are presentation only.
- `models/`: four standalone building GLBs, optional `building_bowl_v02_display.glb` with three separately removable particles, and reusable `energy_mote.glb`. The clean bowl contains no food particles. Particles are 0.70D diameter in this reference-led revision.
- `textures/`: packed and embedded monolith stone colour texture.
- `previews/`: individual perspective, front and top views for 02/03/04. Their toon shader, outlines, ground and lighting are preview-only. GLBs have clean PBR materials, not baked outlines.
- JSON validation files: actual GLB reimport checks and sampled geometric clearances.
- Source scripts: build geometry, optionally add display particles, then render preview. Use a writable package copy.

No game integration, collisions, ground-step/ramp handling, final fixed-camera occlusion, glow animation or tabletop calibration has been implemented. Raised nest/bowl platforms require walkable collision treatment or entry ramps in the game. Never treat the full bowl or nest footprint as a solid obstruction. For the arch, use feet-only collision.

The model is a geometric interpretation of a stylized image, not a scan; hidden surfaces and exact perspective are not specified by the reference. No design diary was read or modified.

## Entry shoulder correction
The nest wall now smoothly decreases in height toward both sides of the entrance, rather than staying level. The rear wall remains 1.90D tall, footprint and floor/pads are unchanged. The lowered shoulders approach approximately 1.24D at the front. Other assets are byte-identical to revision 4.
