# 阳光中心 / Sunlight Center

Reference: supplied concept board column 01 only. Built in Blender 4.3.2.

- Size: 4.40 × 4.40 × 4.950 D. D remains one scene unit.
- Six independent mesh parts: slate circular base, core seat, golden egg-shaped core, and three cream petals (rear higher than left/right).
- Clean PBR base colours and restrained core emission; UVs present on every mesh. No baked light, halo, background or outline.
- `source/Sunlight_Center.blend` contains only the editable architectural asset; `models/building_sunlight_center_v01.glb` contains the exported asset. Preview camera, ground, lighting and toon/outline styling are not in these files.
- `validation.json` records actual GLB reimport checks.

## Runtime requirement, not implemented by this model
The center broadcasts energy over an extremely broad area, restores energy extremely slowly, and becomes weaker with distance. Range, rate, falloff function and gameplay tuning have not been specified or implemented. The golden core and open petal arrangement give a visible source; add any traveling particles or field visualization in the runtime, not in the static mesh.

## Interpretation
The illustrated views are stylized rather than an exact orthographic blueprint. This model keeps the three-petal layout, high rear petal, front opening, warm egg-shaped core and cool low circular base. Exact back surfaces and petal thickness are modeled interpretations. No sample ball is part of the architecture.
