# Prototype A · Reference-led revision 7

Built in Blender 4.3.2 from the user's latest image, columns 02/03/04 only. Column 01 is ignored; the monolith uses the separately approved cold, imposing supply-interface direction.

## Scale and actual geometry
D = 1 scene unit. The user approved reference shape priority over previous overall sizes and flush-ground requirements. The building sizes were increased to preserve both the illustrated proportions and usable clear openings; D itself was not redefined.

- `building_arch_v03.glb`: 5.890 × 2.170 × 4.030D (Blender X/Y/Z).
- `building_bowl_v02.glb`: 7.000 × 7.000 × 1.430D (Blender X/Y/Z).
- `building_bowl_v02_display.glb`: 7.000 × 7.000 × 1.430D (Blender X/Y/Z).
- `building_monolith_v08.glb`: 3.920 × 3.920 × 5.012D (Blender X/Y/Z).
- `building_nest_v03.glb`: 5.220 × 4.640 × 1.900D (Blender X/Y/Z).
- `energy_mote.glb`: 0.700 × 0.700 × 0.700D (Blender X/Y/Z).

Nest: thicker green/cream rounded wall, narrower inward-turning entrance, two separate pads, visible 0.16D raised platform. Sampled entrance clearance 1.353D. Bowl: short rear rim and two long side rims, a visible 0.18D platform, three gaps with sampled clear diameters of 1.419D. Arch: left-low/right-high rounded shoulder, aligned cream bases, 2.047D minimum overhead across a 2.48D-wide central region. Static mesh samples are not a runtime physics guarantee.

## Files and use
- `source/Prototype_A_buildings.blend`: editable meshes, materials and UVs. Four groups are arranged side by side; root empty positions are presentation only.
- `models/`: four standalone building GLBs, optional `building_bowl_v02_display.glb` with three separately removable particles, and reusable `energy_mote.glb`. The clean bowl contains no food particles. Particles are 0.70D diameter in this reference-led revision.
- `textures/`: packed and embedded monolith stone colour texture.
- `previews/`: individual perspective, front and top views for 02/03/04. Their toon shader, outlines, ground and lighting are preview-only. GLBs have clean PBR materials, not baked outlines.
- JSON validation files: actual GLB reimport checks and sampled geometric clearances.
- Source scripts: build geometry, optionally add display particles, then render preview. Use a writable package copy.

No game integration, collisions, ground-step/ramp handling, final fixed-camera occlusion, glow animation or tabletop calibration has been implemented. Raised nest/bowl platforms require walkable collision treatment or entry ramps in the game. Never treat the full bowl or nest footprint as a solid obstruction. For the arch, use feet-only collision.

The model is a geometric interpretation of a stylized image, not a scan; hidden surfaces and exact perspective are not specified by the reference. No design diary was read or modified.

## Entry shoulder correction
The nest wall now smoothly decreases in height toward both sides of the entrance, rather than staying level. The rear wall remains 1.90D tall, footprint and floor/pads are unchanged. The lowered shoulders approach approximately 1.24D at the front. Other assets are byte-identical to revision 4.

## Approved monolith revision
The monolith is now exported as `building_monolith_v08.glb`: muted dark slate-blue, restrained pale-cyan conduits, small chipped corners, and distinct low supply slots with dark hoods and ground-level approach marks. The body stays 3 × 3 × 5D; shallow interface hardware extends beyond that footprint. Separate core, four conduits and four outlets are retained, including directional Flow_UV. Standard PBR base-colour texture contains only colour, no baked light, glow, shadow or outline.

The approved-style scene STUDY image contains illustrative scale balls only. These are not in the saved architectural source or GLB. The standalone monolith render is made from the actual reimported final GLB. Use `source/finalize_monolith.py` after `source/build.py` when rebuilding the full project; it imports the included approved monolith geometry and preserves its standard PBR colours. The other assets are byte-identical to revision 5. Runtime energy animation, glow and actual interaction behavior remain integration work.

## Scene-coordinated monolith
The latest user-approved version retains alien, imposing geometry while adopting the scene’s muted slate-blue palette, low-contrast matte surfaces, restrained cold-white supply features and shared stylized shading. High-contrast stone patterning is intentionally disconnected in the final standard PBR material. The embedded older textures remain source resources, not baked lighting.

## Fifth building: 阳光中心 / Sunlight Center
`building_sunlight_center_v01.glb` is a separate warm energy broadcaster: slate circular base, three cream petals and a golden egg-like core. It is distinct from the cold monolith. Six editable mesh parts, a standalone `Sunlight_Center.blend`, source generator and actual import validation are included. The complete scene contains all five buildings. Run `source/merge_sunlight_center.py` after rebuilding/finalizing the original four if needed.

Requested gameplay: extremely slow energy recovery over an extremely broad area, with the effect weakening with distance. This is a runtime requirement only: range, restoration rate and falloff are not implemented in the model or implied by a baked halo. See the separate Sunlight Center README.

Final sunlight dimensions: 4.400 × 4.400 × 4.950D. Final GLB and full-source validation reports confirm five building roots, UVs on all exported meshes, finite geometry, and no preview cameras/lights/characters in the architectural source.
