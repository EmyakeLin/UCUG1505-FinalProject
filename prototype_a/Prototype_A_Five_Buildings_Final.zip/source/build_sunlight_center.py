import bpy,math,os,json,bmesh
from mathutils import Vector
B=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bpy.ops.wm.read_factory_settings(use_empty=True)
root=bpy.data.objects.new('building_sunlight_center',None);bpy.context.collection.objects.link(root)
root['name_zh']='阳光中心';root['unit']='D=1 scene unit';root['runtime_requirement']='Extremely slow energy restoration over a very broad area, weakening with distance. Not implemented by this model.'
def mat(n,h,em=0):
 rgb=[int(h[i:i+2],16)/255 for i in (0,2,4)];c=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in rgb]
 m=bpy.data.materials.new(n);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=.8;p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=em;return m
cream=mat('sunlight_shell_cream','F1D8AD');inside=mat('sunlight_shell_inner','C49D68');base=mat('sunlight_base_slate','627B80');rim=mat('sunlight_base_top','8FA3A2');gold=mat('sunlight_core_gold','FFC335',.4);stemmat=mat('sunlight_core_seat','967245')
def mesh(n,vs,fs,mats,mi=None,bevel=0):
 me=bpy.data.meshes.new(n+'_mesh');me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(o);o.parent=root
 for m in mats:me.materials.append(m)
 for p in me.polygons:p.use_smooth=True
 if mi:
  for p,i in zip(me.polygons,mi):p.material_index=i
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free()
 if bevel:
  mod=o.modifiers.new('Soft ceramic edges','BEVEL');mod.width=bevel;mod.segments=4;mod.limit_method='ANGLE';mod.angle_limit=.35;mod.use_clamp_overlap=True
 return o
# Circular low drum, softly rounded lip.
vs=[];N=80;profile=[(2.07,0),(2.18,.055),(2.2,.15),(2.2,.34),(2.15,.43),(2.04,.47)]
for rad,z in profile:
 for j in range(N):a=math.tau*j/N;vs.append((rad*math.cos(a),rad*math.sin(a),z))
fs=[];mi=[]
for k in range(len(profile)-1):
 for j in range(N):fs.append((k*N+j,k*N+(j+1)%N,(k+1)*N+(j+1)%N,(k+1)*N+j));mi.append(0 if k<4 else 1)
fs +=[tuple(reversed(range(N))),tuple((len(profile)-1)*N+j for j in range(N))];mi +=[0,1];mesh('sunlight_base',vs,fs,[base,rim],mi)
# Three thick, curved ceramic petals. Rear is taller; side petals open toward the viewer.
for name,a0,a1,h in [('back',40,140,4.95),('left',150,265,3.92),('right',275,390,3.92)]:
 U=44;V=22;vs=[]
 for side in [0,1]:
  for k in range(V+1):
   v=k/V
   for j in range(U+1):
    t=j/U;u=2*t-1
    # Rounded crown: petal ends lower than the crown, giving a soft open cradle.
    crown=h-.92*abs(u)**2.6
    z=.43+(crown-.43)*v
    ang=math.radians(a0+(a1-a0)*t)
    outer=1.80+.22*math.sin(math.pi*v)-.27*v**3
    rad=outer-(.38 if side else 0)
    vs.append((rad*math.cos(ang),rad*math.sin(ang),z))
 n=(U+1)*(V+1);fs=[];mi=[]
 for side in [0,1]:
  for k in range(V):
   for j in range(U):
    a=side*n+k*(U+1)+j;f=(a,a+1,a+U+2,a+U+1);fs.append(tuple(reversed(f)) if side else f);mi.append(side)
 for k in range(V):
  for j in [0,U]:
   a=k*(U+1)+j;b=a+U+1;fs.append((a,b,b+n,a+n));mi.append(0)
 for k in [0,V]:
  for j in range(U):
   a=k*(U+1)+j;fs.append((a,a+n,a+n+1,a+1));mi.append(0)
 mesh('sunlight_petal_'+name,vs,fs,[cream,inside],mi,.13)
# Warm egg-shaped core, visible through open shell; no baked glow or particle geometry.
vs=[];N=64;R=36
for i in range(R+1):
 t=math.pi*i/R;z=2.62+1.38*math.cos(t);rad=.90*math.sin(t)*(1-.22*math.cos(t))
 for j in range(N):a=math.tau*j/N;vs.append((rad*math.cos(a),rad*math.sin(a),z))
fs=[]
for i in range(R):
 for j in range(N):fs.append((i*N+j,i*N+(j+1)%N,(i+1)*N+(j+1)%N,(i+1)*N+j))
mesh('sunlight_energy_core',vs,fs,[gold])
bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.58,depth=.92,location=(0,0,.93));o=bpy.context.object;o.name='sunlight_core_seat';o.parent=root;o.data.materials.append(stemmat)
for o in root.children:
 if o.type=='MESH':
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.select_all(action='SELECT');bpy.ops.export_scene.gltf(filepath=B+'/models/building_sunlight_center_v01.glb',export_format='GLB',use_selection=True,export_apply=True)
bpy.ops.wm.save_as_mainfile(filepath=B+'/source/Sunlight_Center.blend')
# Render-only stage, not saved or exported.
scene=bpy.context.scene;scene.world=bpy.data.worlds.new('PreviewWorld');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.35
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.render.resolution_x=900;scene.render.resolution_y=900;scene.render.resolution_percentage=100
for m in [cream,inside,base,rim,stemmat]:
 p=m.node_tree.nodes.get('Principled BSDF');c=p.inputs['Base Color'].default_value[:];m.node_tree.nodes.clear();out=m.node_tree.nodes.new('ShaderNodeOutputMaterial');toon=m.node_tree.nodes.new('ShaderNodeBsdfToon');toon.inputs['Color'].default_value=tuple(x**.65 for x in c[:3])+(1,);toon.inputs['Size'].default_value=.72;toon.inputs['Smooth'].default_value=.08;m.node_tree.links.new(toon.outputs[0],out.inputs['Surface'])
bpy.ops.mesh.primitive_plane_add(size=100);o=bpy.context.object;o.location.z=-.015;o.data.materials.append(mat('PREVIEW_ground','EFE6D4'))
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.light_add(type='SUN',location=(-4,-6,9));o=bpy.context.object;o.data.energy=2.4;o.data.angle=.08;aim(o,(0,0,0))
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=6.3;scene.camera=cam
scene.render.use_freestyle=True;ls=bpy.context.view_layer.freestyle_settings.linesets[0];ls.linestyle=bpy.data.linestyles.new('Outline');ls.select_crease=False;ls.linestyle.color=(.12,.10,.08);ls.linestyle.thickness=2
for name,loc,target in [('perspective',(2,-10,7),(0,0,2.3)),('front',(0,-12,4.5),(0,0,2.3)),('top',(0,0,12),(0,0,0))]:
 cam.location=loc;aim(cam,target);scene.render.filepath=B+'/previews/sunlight_center_'+name+'.png';bpy.ops.render.render(write_still=True)
