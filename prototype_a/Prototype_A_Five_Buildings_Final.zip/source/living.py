import bpy,math,bmesh
from mathutils import Vector

def lv_mat(name,hexcolor):
 m=bpy.data.materials.get(name) or bpy.data.materials.new(name);m.use_nodes=True
 rgb=tuple(int(hexcolor[i:i+2],16)/255 for i in (0,2,4));col=tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in rgb)+(1,)
 m.diffuse_color=col;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=col;p.inputs['Roughness'].default_value=.82
 return m

def lv_root(name):
 r=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(r);r.empty_display_type='PLAIN_AXES';r['unit_D']=1.;return r

def lv_mesh(name,verts,faces,root,mats,mi=None,smooth=True):
 me=bpy.data.meshes.new(name+'_mesh');me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.parent=root
 for m in mats:me.materials.append(m)
 for p in me.polygons:p.use_smooth=smooth
 if mi:
  for p,i in zip(me.polygons,mi):p.material_index=i
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free()
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
 return o

def lv_disc(name,root,rx,ry,z0,z1,mats,ring=False):
 n=64;vs=[]
 # rounded low-profile edge; inset pad colour rim (not outline)
 profiles=[(.96,z0),(1,z0+(z1-z0)*.3),(1,z0+(z1-z0)*.7),(.96,z1),(.90,z1)] if ring else [(.98,z0),(1,z0+(z1-z0)*.3),(1,z0+(z1-z0)*.7),(.98,z1)]
 for f,z in profiles:
  for j in range(n):a=math.tau*j/n;vs.append((rx*f*math.cos(a),ry*f*math.sin(a),z))
 fs=[];mi=[]
 for i in range(len(profiles)-1):
  for j in range(n):fs.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j));mi.append(1 if ring and i==3 else 0)
 fs += [tuple(reversed(range(n))),tuple((len(profiles)-1)*n+j for j in range(n))];mi +=[0,0]
 return lv_mesh(name,vs,fs,root,mats,mi)

def lv_round_arc(name,root,rx,ry,t,a,b,h,mats,caplen=.14,flare=0):
 # Rounded-rectangle section, dome-capped ends. Broad surfaces instead of flat-cut wall tips.
 P=20;n=max(32,int((b-a)/2));vs=[];rings=[]
 def profile(k):
  v=math.tau*k/P;c=math.cos(v);s=math.sin(v)
  return (t/2*math.copysign(abs(c)**.42,c),h/2+h/2*math.copysign(abs(s)**.32,s))
 for j in range(1,5):rings.append((a,-caplen*math.cos(j*math.pi/10),math.sin(j*math.pi/10)))
 rings +=[(a+(b-a)*j/n,0,1) for j in range(n+1)]
 for j in range(1,5):rings.append((b,caplen*math.sin(j*math.pi/10),math.cos(j*math.pi/10)))
 for ang,extension,f in rings:
  u=math.radians(ang);cx=rx*math.cos(u);cy=ry*math.sin(u);normal=Vector((math.cos(u),math.sin(u),0));tang=Vector((-rx*math.sin(u),ry*math.cos(u),0)).normalized()
  for k in range(P):
   off,z=profile(k);uu=math.radians(ang+(ang-(a+b)/2)/((b-a)/2)*flare*off/(t/2));nn=Vector((math.cos(uu),math.sin(uu),0));tt=Vector((-rx*math.sin(uu),ry*math.cos(uu),0)).normalized();v=Vector((rx*math.cos(uu),ry*math.sin(uu),h/2))+nn*off*f+tt*extension;v.z=h/2+(z-h/2)*f;vs.append(tuple(v))
 fs=[];mi=[]
 for j in range(len(rings)-1):
  for k in range(P):fs.append((j*P+k,j*P+(k+1)%P,(j+1)*P+(k+1)%P,(j+1)*P+k));mi.append(1 if len(mats)>1 and P*.30<=k<P*.70 and 5<=j<len(rings)-6 else 0)
 # Close round cap poles; central cap is same outer material, with no raw planar cut surface.
 for start,ang,extension in [(True,a,-caplen),(False,b,caplen)]:
  u=math.radians(ang);tang=Vector((-rx*math.sin(u),ry*math.cos(u),0)).normalized();point=Vector((rx*math.cos(u),ry*math.sin(u),h/2))+tang*extension;idx=len(vs);vs.append(tuple(point));base=0 if start else (len(rings)-1)*P
  for k in range(P):fs.append((idx,base+(k+1)%P,base+k) if start else (idx,base+k,base+(k+1)%P));mi.append(0)
 return lv_mesh(name,vs,fs,root,mats,mi)

def build_nest():
 r=lv_root('building_nest');green=lv_mat('nest_wall','8BA99C');cream=lv_mat('nest_inner','E9D8B5');pad=lv_mat('nest_pad','CEBB96');seam=lv_mat('nest_pad_edge','AC9573')
 wall=lv_round_arc('nest_wall',r,1.55,1.35,.50,-66,246,1.2,[green,cream],.14)
 ys=[v.co.y for v in wall.data.vertices];mn,mx=min(ys),max(ys)
 for v in wall.data.vertices:v.co.y=(v.co.y-(mn+mx)/2)*3.2/(mx-mn)
 lv_disc('nest_floor',r,1.73,1.53,-.018,0,[cream])
 for name,x in [('nest_pad_a',-.64),('nest_pad_b',.64)]:
  o=lv_disc(name,r,.55,.46,0,.018,[pad,seam],True);o.location=(x,.12,0)
 
 for o in r.children:
  for v in o.data.vertices:v.co*=1.45
  o.location*=1.45
 # Visible reference-style plinth; raise walls and pads with the platform.
 for o in r.children:
  for v in o.data.vertices:v.co.z+=.16
 
 for v in bpy.data.objects['nest_floor'].data.vertices:
  v.co.z=(v.co.z-(.16-.018*1.45))/(.018*1.45)*.16

 for v in bpy.data.objects['nest_wall'].data.vertices:
  t=max(0,min(1,(-v.co.y-.1)/2.10));q=t*t*(3-2*t);v.co.z=.16+(v.co.z-.16)*(1-.38*q)
 r['collision_note']='Reference-style raised platform .16D; use ramp or step handling in runtime.'
 return r

def build_bowl():
 r=lv_root('building_bowl');red=lv_mat('bowl_rim','D68C6D');cream=lv_mat('bowl_inner','E9D8B5')
 lv_disc('bowl_floor',r,3.5,3.5,0,.18,[cream])
 # Thick gently rounded ceramic sections. Gap sizing overrides narrower concept openings.
 # Inner radius 1.10; curved caps occupy <=0.10 tangentially, so conservative clear gap remains >1.3.
 for i,(a,b) in enumerate([(54,126),(159,253.5),(286.5,381)]):
  ob=lv_round_arc('bowl_rim_'+chr(97+i),r,3.0,3.0,1.0,a,b,1.25,[red],.025,0)
  for v in ob.data.vertices:v.co.z+=.18
 r['gap_design']='Flared rim end faces: wider outer rim arcs with clear inner-radius passages; checked from exported geometry.'
 r['collision_note']='Only three ceramic rims block travel, not the floor.'
 mote_root=lv_root('energy_mote_asset');gold=lv_mat('energy_mote','F5C75B')
 bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=.35,location=(0,0,.35));o=bpy.context.object;o.name='energy_mote';o.parent=mote_root;o.data.materials.append(gold)
 for p in o.data.polygons:p.use_smooth=True
 return r,mote_root

def lv_base(name,root,x,mat):
 n=64;profile=[(.83,0),(.94,.035),(1,.13),(1,.32),(.96,.45),(.86,.52)];vs=[]
 for fac,z in profile:
  for j in range(n):a=j*math.tau/n;vs.append((x+.575*fac*math.cos(a),0+.7*fac*math.sin(a),z))
 fs=[]
 for i in range(len(profile)-1):
  for j in range(n):fs.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 fs += [tuple(reversed(range(n))),tuple((len(profile)-1)*n+j for j in range(n))]
 return lv_mesh(name,vs,fs,root,[mat])

def bez(p0,p1,p2,p3,t):return tuple((1-t)**3*p0[i]+3*(1-t)**2*t*p1[i]+3*(1-t)*t*t*p2[i]+t**3*p3[i] for i in range(2))
def build_arch():
 r=lv_root('building_arch');purple=lv_mat('arch_beam','AA96BC');cream=lv_mat('arch_feet','E9D8B5')
 for side,x in [('l',-1.325),('r',1.325)]:lv_base('arch_foot_'+side,r,x,cream)
 curves=[((-1.3,.38),(-1.34,1.12),(-1.23,1.65),(-.84,1.88)),((-.84,1.88),(-.45,2.11),(.65,2.52),(.98,2.27)),((.98,2.27),(1.31,2.02),(1.31,1.10),(1.3,.38))]
 path=[]
 for c in curves:path.extend(bez(*c,j/32) for j in range(32))
 path.append(curves[-1][-1]);P=32;vs=[]
 for i,(x,z) in enumerate(path):
  prev=Vector(path[max(0,i-1)]);nxt=Vector(path[min(len(path)-1,i+1)]);t=(nxt-prev).normalized();normal=Vector((-t.y,0,t.x));depth=.275+.225*max(0,min(1,(1.5-z)/1.0))
  for j in range(P):
   phi=math.tau*j/P;c=math.cos(phi);ss=math.sin(phi);a=.38*math.copysign(abs(c)**.80,c);b=depth*math.copysign(abs(ss)**.80,ss)
   cy=0;v=Vector((x,b+cy,z))+normal*a;vs.append(tuple(v))
 fs=[]
 for i in range(len(path)-1):
  for j in range(P):fs.append((i*P+j,i*P+(j+1)%P,(i+1)*P+(j+1)%P,(i+1)*P+j))
 fs +=[tuple(reversed(range(P))),tuple((len(path)-1)*P+j for j in range(P))]
 ob=lv_mesh('arch_beam',vs,fs,r,[purple]);maxz=max(v.co.z for v in ob.data.vertices)
 for v in ob.data.vertices:v.co.z*=2.6/maxz
 
 for o in r.children:
  for v in o.data.vertices:v.co*=1.55
 r['collision_note']='Reference silhouette scaled 1.55 to provide about 2D clear overhead across a broad central passage.'
 return r
