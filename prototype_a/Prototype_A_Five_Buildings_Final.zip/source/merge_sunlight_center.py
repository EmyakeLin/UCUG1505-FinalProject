import bpy,os
B=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));bpy.ops.wm.open_mainfile(filepath=B+'/source/Prototype_A_buildings.blend')
with bpy.data.libraries.load(os.path.join(os.path.dirname(os.path.abspath(__file__)),'Sunlight_Center.blend'),link=False) as (src,dst):dst.objects=src.objects
col=bpy.data.collections.new('building_sunlight_center_v01');bpy.context.scene.collection.children.link(col)
for o in dst.objects:
 if o:col.objects.link(o)
r=bpy.data.objects['building_sunlight_center'];r.location=(18,0,0)
bpy.ops.wm.save_as_mainfile(filepath=B+'/source/Prototype_A_buildings.blend')
