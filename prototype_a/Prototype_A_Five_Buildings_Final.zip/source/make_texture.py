from PIL import Image,ImageDraw,ImageFilter
import random,math,os
random.seed(92);N=1024
im=Image.new('RGB',(N,N),(27,32,41));d=ImageDraw.Draw(im)
for i in range(420):
 x=random.randrange(-80,N);y=random.randrange(-80,N);r=random.randint(12,100)
 pts=[(x+math.cos(a)*r*random.uniform(.5,1.3),y+math.sin(a)*r*random.uniform(.5,1.3)) for a in [j*math.tau/7 for j in range(7)]]
 v=random.choice([22,25,29,33,36]);d.polygon(pts,fill=(v,v+5,v+13))
for i in range(55):
 x=random.randrange(N);y=random.randrange(N);pts=[(x,y)]
 for j in range(random.randint(2,5)):
  x+=random.randint(-15,18);y+=random.randint(5,19);pts.append((x,y))
 d.line(pts,fill=(19,23,30),width=2)
for i in range(300):
 x=random.randrange(N);y=random.randrange(N);r=random.randint(1,3);d.ellipse((x,y,x+r,y+r),fill=(20,25,32))
im.save(os.path.join(os.path.dirname(__file__),'../textures/monolith_stone_basecolor.png'))
