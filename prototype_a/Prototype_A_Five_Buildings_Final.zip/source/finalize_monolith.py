import bpy,os,json
B=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));old=os.path.join(os.path.dirname(os.path.abspath(__file__)),'monolith_approved_geometry.blend')
bpy.ops.wm.open_mainfile(filepath=B+'/source/Prototype_A_buildings.blend')
r=bpy.data.objects['building_monolith'];loc=r.location.copy()
for o in list(r.children_recursive)+[r]:bpy.data.objects.remove(o,do_unlink=True)
with bpy.data.libraries.load(old,link=False) as (src,dst):dst.objects=src.objects
for o in dst.objects:
 if o:bpy.context.scene.collection.objects.link(o)
r=next(o for o in dst.objects if o and o.name=='building_monolith');r.location=(0,0,0)
for o in r.children_recursive:
 if o.type=='MESH' and not o.data.uv_layers:
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.select_all(action='DESELECT');r.select_set(True)
for o in r.children_recursive:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=B+'/models/building_monolith_v08.glb',export_format='GLB',use_selection=True,export_apply=True)
r.location=loc;bpy.ops.wm.save_as_mainfile(filepath=B+'/source/Prototype_A_buildings.blend')
