import bpy,math,os,json,sys
from mathutils import Vector
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,col,emit=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Roughness'].default_value=.85
 if emit:p.inputs['Emission Color'].default_value=(*col,1);p.inputs['Emission Strength'].default_value=emit
 return m
stone=mat('monolith_stone',(.025,.035,.05));n=stone.node_tree.nodes.new('ShaderNodeTexImage');im=bpy.data.images.load(BASE+'/textures/monolith_stone_basecolor.png');im.pack();n.image=im;stone.node_tree.links.new(n.outputs['Color'],stone.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
coremat=mat('energy_core',(.58,.92,1),1.5);inlaymats={s:mat('energy_conduit_'+s,(.32,.82,.94),1) for s in 'nesw'};outmats={s:mat('energy_outlet_'+s,(.65,.96,1),1.5) for s in 'nesw'};frame=mat('monolith_frame',(.045,.065,.085))
def cube(name,loc,dim,material=None,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if material:o.data.materials.append(material)
 if bevel:
  mod=o.modifiers.new('Edge micro bevel','BEVEL');mod.width=bevel;mod.segments=2
 return o
def boolean(body,c):
 bpy.context.view_layer.objects.active=body;mod=body.modifiers.new('Recess','BOOLEAN');mod.object=c;mod.operation='DIFFERENCE';bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(c,do_unlink=True)
def root(name):
 o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o['unit']='D = 1 scene unit; not physical metres';return o
def coords(u,v,z,a):return (u*math.cos(a)-v*math.sin(a),u*math.sin(a)+v*math.cos(a),z)
def boxside(name,u,v,z,du,dv,dz,a,material=None):
 o=cube(name,coords(u,v,z,a),(du,dv,dz),material);o.rotation_euler.z=a;return o
r=root('building_monolith');body=cube('monolith_body',(0,0,2.5),(3,3,5),stone)
boolean(body,cube('core_cut',(0,0,5.02),(1,1,.40)))
inlays=[]
for s,a in [('s',0),('e',math.pi/2),('n',math.pi),('w',3*math.pi/2)]:
 # Side local front -Y, two right-angle turns; top strip joins at edge.
 segs=[(0,-1.48,3.8,.14,.14,2.54),(.175,-1.48,2.6,.49,.14,.14),(.35,-1.48,1.465,.14,.14,2.34)]
 for u,v,z,du,dv,dz in segs:boolean(body,boxside('groove_cut',u,v,z,du,dv,dz,a))
 boolean(body,boxside('top_groove',0,-1.01,4.98,.14,1.06,.14,a))
 boolean(body,boxside('outlet_cut',.35,-1.49,.4,.9,.18,.25,a))
 # Build continuous thin ribbon mesh (UV U cumulative flow distance, V width)
 path=[(0,-.5,4.935),(0,-1.435,4.935),(0,-1.435,2.6),(.35,-1.435,2.6),(.35,-1.435,.4)]
 verts=[];faces=[];dist=[0]
 for i in range(1,len(path)):dist.append(dist[-1]+(Vector(path[i])-Vector(path[i-1])).length)
 # planar ribbon per segment joined into named mesh, overlap at corners deliberate .045 extension
 for i,(p,q) in enumerate(zip(path,path[1:])):
  p,q=Vector(p),Vector(q);t=(q-p).normalized();side=Vector((1,0,0)) if i in [0,1,3] else Vector((0,0,1));p-=t*.045;q+=t*.045
  k=len(verts)
  for vv in [p-side*.045,p+side*.045,q+side*.045,q-side*.045]:verts.append(coords(vv.x,vv.y,vv.z,a))
  faces.append((k,k+1,k+2,k+3))
 me=bpy.data.meshes.new('flow_ribbon');me.from_pydata(verts,[],faces);me.update();ob=bpy.data.objects.new('conduit_'+s,me);bpy.context.collection.objects.link(ob);ob.data.materials.append(inlaymats[s]);ob.parent=r
 uv=me.uv_layers.new(name='Flow_UV')
 for poly,i in zip(me.polygons,range(4)):
  vals=[(dist[i],0),(dist[i],1),(dist[i+1],1),(dist[i+1],0)]
  for li,val in zip(poly.loop_indices,vals):uv.data[li].uv=val
 solid=ob.modifiers.new('Inlay thickness','SOLIDIFY');solid.thickness=.009
 ob['flow_uv']='U increases core to outlet in D distance; V across width'
 out=boxside('outlet_'+s,.35,-1.415,.4,.86,.012,.21,a,outmats[s]);out.parent=r
# core faceted cap
verts=[(-.46,-.46,2.835),(.46,-.46,2.835),(.46,.46,2.835),(-.46,.46,2.835),(-.46,-.46,2.88),(.46,-.46,2.88),(.46,.46,2.88),(-.46,.46,2.88),(0,0,2.97),(.15,-.18,2.935)]
verts=[(x,y,z+2) for x,y,z in verts]
faces=[(0,3,2,1),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,9),(5,6,9),(6,8,9),(6,7,8),(7,4,8),(4,9,8)]
me=bpy.data.meshes.new('FacetedCore');me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new('energy_core',me);bpy.context.collection.objects.link(o);o.data.materials.append(coremat);o.data.materials.append(mat('energy_core_facet',(.32,.7,.82),.7));o.parent=r
for pp in me.polygons:pp.material_index=pp.index%2
# flush dark frame outside recess
for name,loc,dim in [('N',(0,.56,2.98),(1.24,.12,.04)),('S',(0,-.56,2.98),(1.24,.12,.04)),('E',(.56,0,2.98),(.12,1,.04)),('W',(-.56,0,2.98),(.12,1,.04))]:
 # interrupt central span to preserve continuous channel from core
 axis=0 if name in 'NS' else 1
 for sign in [-1,1]:
  l=list(loc);d=list(dim);l[2]=5.006;d[2]=.012;l[axis]=sign*(.345 if name in 'NS' else .285);d[axis]=.55 if name in 'NS' else .43;ob=cube('core_frame_'+name+str(sign),l,d,frame,.006);ob.parent=r
body.parent=r;bpy.context.view_layer.objects.active=body;mod=body.modifiers.new('Stone micro bevel','BEVEL');mod.width=.008;mod.segments=2
# shell UV generated over geometric recesses
bpy.ops.object.select_all(action='DESELECT');body.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.015);bpy.ops.object.mode_set(mode='OBJECT')
roots=[r]
from living import build_nest,build_bowl,build_arch
nest=build_nest();bowl,mote_root=build_bowl();arch=build_arch();roots.extend([nest,bowl,arch])
# UV for all mesh parts except directionally unwrapped strips
for o in list(bpy.data.objects):
 if o.type=='MESH' and not o.data.uv_layers:
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
# pack and save source with assets arranged for overview, export at origin individually
names=['building_monolith_v06','building_nest_v03','building_bowl_v02','building_arch_v03']
report={}
for r,name in zip(roots,names):
 bpy.ops.object.select_all(action='DESELECT');r.select_set(True)
 for ob in r.children_recursive:ob.select_set(True)
 bpy.context.view_layer.objects.active=r
 bpy.ops.export_scene.gltf(filepath=BASE+'/models/'+name+'.glb',export_format='GLB',use_selection=True,export_apply=True,export_yup=True)
 obs=[x for x in r.children_recursive if x.type=='MESH'];report[name]={'mesh_objects':len(obs),'vertices_source':sum(len(x.data.vertices) for x in obs),'parts':[x.name for x in obs]}
# separate energy mote export if present
mote=bpy.data.objects.get('energy_mote')
if mote:
 bpy.ops.object.select_all(action='DESELECT');mote.select_set(True);bpy.ops.export_scene.gltf(filepath=BASE+'/models/energy_mote.glb',export_format='GLB',use_selection=True,export_apply=True)
# editable source, all at origin in separate collections; viewport hide other groups as needed
for r,name in zip(roots,names):
 col=bpy.data.collections.new(name);bpy.context.scene.collection.children.link(col)
 for o in [r]+list(r.children_recursive):
  for c in list(o.users_collection):c.objects.unlink(o)
  col.objects.link(o)
 r.hide_render=True

# Present editable assets separated in source; each export above remains origin-centered.
for rr,xx in zip(roots,[-10,-4,3,10]):rr.location.x=xx
mote_root.location=(2,0,.1)
bpy.ops.wm.save_as_mainfile(filepath=BASE+'/source/Prototype_A_buildings.blend')
for rr in roots:rr.location.x=0
for oo in [mote_root]+list(mote_root.children_recursive):oo.hide_render=True
# preview stage only, not saved in delivered source and never in GLBs
for r in roots:
 for o in [r]+list(r.children_recursive):o.hide_render=True
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.render.resolution_x=900;scene.render.resolution_y=850;scene.render.resolution_percentage=100
scene.world.color=(.3,.3,.3);scene.view_settings.view_transform='AgX'
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.05));plane=bpy.context.object;plane.data.materials.append(mat('Preview ground only',(.68,.72,.72)))
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for loc,power,size in [((3,-4,7),600,5),((-4,-1,5),250,4),((1,5,6),700,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.data.energy=power;l.data.shape='DISK';l.data.size=size;aim(l,(0,0,1))
bpy.ops.object.camera_add(location=(5,-8,9));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=5.5;scene.camera=cam;aim(cam,(0,0,.9))
for r,name in zip(roots,names):
 if os.environ.get('NO_RENDER') or r==roots[0]:continue
 cam.data.ortho_scale=7 if r==roots[0] else 5.5
 cam.location=(6,-10,8) if r==roots[0] else (4,-8,6)
 aim(cam,(0,0,2.4) if r==roots[0] else (0,0,.9))
 for o in [r]+list(r.children_recursive):o.hide_render=False
 scene.render.filepath=BASE+'/previews/'+name+'_perspective.png';bpy.ops.render.render(write_still=True)
 for angle,loc,target in [('front',(0,-10,3),(0,0,1)),('top',(0,0,12),(0,0,0))]:
  cam.location=loc;aim(cam,target);scene.render.filepath=BASE+'/previews/'+name+'_'+angle+'.png';bpy.ops.render.render(write_still=True)
 for o in [r]+list(r.children_recursive):o.hide_render=True
json.dump(report,open(BASE+'/validation_source.json','w'),indent=2)
