import bpy,os
B=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));bpy.ops.wm.open_mainfile(filepath=B+'/source/Prototype_A_buildings.blend');r=bpy.data.objects['building_bowl'];m=bpy.data.objects['energy_mote'];saved=r.location.copy();r.location=(0,0,0)
for o in list(bpy.data.objects):
 if o.name.startswith('display_energy_mote_'):bpy.data.objects.remove(o,do_unlink=True)
for name,(x,y) in zip(['a','b','c'],[(-.7,-.44),(.7,-.44),(0,.8)]):
 ob=m.copy();ob.data=m.data.copy();bpy.context.collection.objects.link(ob);ob.parent=r;ob.name='display_energy_mote_'+name;ob.location=(x,y,.53);ob.hide_render=False
 for col in list(ob.users_collection):col.objects.unlink(ob)
 r.users_collection[0].objects.link(ob)
bpy.ops.object.select_all(action='DESELECT');r.select_set(True)
for o in r.children_recursive:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=B+'/models/building_bowl_v02_display.glb',export_format='GLB',use_selection=True,export_apply=True)
r.location=saved;m.hide_render=True;m.hide_set(True);bpy.ops.wm.save_as_mainfile(filepath=B+'/source/Prototype_A_buildings.blend')
