import bpy,math,os
from mathutils import Vector
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bpy.ops.wm.open_mainfile(filepath=BASE+'/source/Prototype_A_buildings.blend')
for o in list(bpy.data.objects):
 if o.name.startswith('display_energy_mote_'):bpy.data.objects.remove(o,do_unlink=True)
roots=[bpy.data.objects[n] for n in ['building_monolith','building_nest','building_bowl','building_arch']]
for r in roots:
 r.location=(0,0,0)
 for o in [r]+list(r.children_recursive):o.hide_render=True
mote=bpy.data.objects['energy_mote'];mote.parent.location=(0,0,0);mote.hide_render=True
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.cycles.max_bounces=2
scene.render.resolution_x=800;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(1,1,1,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.25
# Preview-only toon materials. Exported GLBs retain standard PBR and no outline.
for m in bpy.data.materials:
 if not m.use_nodes or 'energy' in m.name or 'monolith' in m.name:continue
 p=m.node_tree.nodes.get('Principled BSDF')
 if not p:continue
 col=p.inputs['Base Color'].default_value[:];m.node_tree.nodes.clear();out=m.node_tree.nodes.new('ShaderNodeOutputMaterial');toon=m.node_tree.nodes.new('ShaderNodeBsdfToon');toon.inputs['Color'].default_value=col;toon.inputs['Size'].default_value=.72;toon.inputs['Smooth'].default_value=.04;m.node_tree.links.new(toon.outputs[0],out.inputs['Surface'])
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.022));plane=bpy.context.object;plane.name='PREVIEW_GROUND';m=bpy.data.materials.new('PreviewBackground');m.diffuse_color=(.94,.90,.83,1);plane.data.materials.append(m)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.light_add(type='SUN',location=(-4,-6,9));sun=bpy.context.object;sun.data.energy=1.3;sun.data.angle=.06;aim(sun,(0,0,0))
bpy.ops.object.camera_add(location=(4,-8,6));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=7.7;scene.camera=cam
scene.render.use_freestyle=True
lines=bpy.context.view_layer.freestyle_settings.linesets[0];lines.select_crease=False;lines.select_silhouette=True;lines.select_border=True;lines.linestyle.color=(.08,.065,.06);lines.linestyle.thickness=2.5
names=['building_monolith_v06','building_nest_v03','building_bowl_v02','building_arch_v03']
for i in [3,1,2]:
 r=roots[i]
 for o in [r]+list(r.children_recursive):o.hide_render=False
 copies=[]
 if i==2:
  for x,y in [(-.7,-.44),(.7,-.44),(0,.8)]:
   o=mote.copy();o.data=mote.data.copy();bpy.context.collection.objects.link(o);o.parent=None;o.location=(x,y,.53);o.hide_render=False;copies.append(o)
 for angle,loc,target in [('perspective',((1,-10,5.5) if i==3 else (2,-8,9)),(0,0,1.3)),('front',(0,-10,4.0),(0,0,1.8)),('top',(0,0,12),(0,0,0))]:
  cam.location=loc;aim(cam,target);scene.render.filepath=BASE+'/previews/'+names[i]+'_styled_'+angle+'.png';bpy.ops.render.render(write_still=True)
  if os.environ.get('TEST'):break
 for o in copies:bpy.data.objects.remove(o,do_unlink=True)
 for o in [r]+list(r.children_recursive):o.hide_render=True
 if os.environ.get('TEST'):break
