# AI Usage Declaration

本项目使用 OpenAI Codex 辅助准备与开发。本文档记录 AI 实际执行的文件修改及相关协助，不是 design diary，也不替代学生本人的创作记录与反思。

## 使用边界

- 以项目根目录 `AGENTS.md` 和用户后续明确要求为依据。
- AI 不参与 design diary 的写作、代写或润色。
- AI 每次修改项目文件时，同步在本文档记录修改范围与内容。
- 不将尚未实现、运行或验证的内容描述为已完成。

## 已确认的开发约束

- Prototype A 截止时间：2026 年 11 月 9 日上午 11:59（Asia/Shanghai，北京时间）。
- 使用 p5.js；可按需使用 three.js、matter.js。
- Prototype A 的交互全部在屏幕内完成，目标是可玩、好玩的游戏；实体交互留给 Prototype B 和 Prototype C。
- 遵循用户要求，不主动扩展项目理念或探索评分标准。

## AI 协助与修改记录

### 2026-11-08：开发准备

- 使用工具：OpenAI Codex。
- 协助内容：读取根目录 `AGENTS.md`；检查工作目录及 `project_spec`、`prototype_a` 的文件状态；确认截止时间和开发工具约束。
- 检查结果：`project_spec`、`prototype_a` 当前为空；项目根目录当前不是 Git 仓库。
- 新增文件：`AI usage declaration.md`，建立 AI 使用边界、开发约束和修改追踪记录。
- 未读取或修改 `design_diary` 内的内容；未生成游戏代码、设计文稿或测试。

### 2026-11-08：世界日常建筑设计

- 使用工具：OpenAI Codex 与内置 image_gen 图像生成工具；使用 imagegen 技能及 write-page 写作规范。
- 用户要求：暂缓灾难与拯救叙事，先为小球的日常世界设计三渲二、卡通、粗勾边建筑，供用户自行建模。
- 协助内容：设计供能巨碑、睡眠窝、分享食盆、游玩拱门，给出统一比例、拆件、材质区域、通行空间、俯视可见性和资产交付建议。这些是 AI 提出的建模方案，尚未作为完成的游戏功能。
- 新增 `project_spec/建筑建模说明_v01.md`：建模交接说明；不属于 design diary。
- 新增 `project_spec/building-concepts-v01.png`：AI 生成的四建筑概念板，从工具生成目录复制至项目。
- 新增 `project_spec/building-concepts-v01.prompt.txt`：保存生成概念板使用的完整提示词。
- 更新 `AI usage declaration.md`：记录本次文件修改和 AI 图像生成。
- 验证：已目视检查生成图；图中比例与部分投影不精确，已在建模说明中标注以文字尺寸为准。本次未创建 3D 模型、未实现渲染或碰撞、未进行游戏运行测试。
- 未读取或修改 `design_diary` 内的内容。

### 2026-11-08：按 2001 太空漫游修订巨碑

- 用户要求：巨碑参考斯坦利·库布里克与亚瑟·克拉克的《2001太空漫游》。
- AI 协助：查阅电影制作资料和小说巨碑比例资料；将种子状供能建筑改为无装饰的黑色直立长方体，采用厚宽高 1:4:9 的设计比例；修正固定视野被过度限定为垂直俯视的假设。
- 修改 `project_spec/建筑建模说明_v01.md`：替换巨碑形体、尺寸、材质、拆件、碰撞和检查要求；标明旧图 01 作废，新增来源链接与镜头可见性限制。
- 新增 `project_spec/monolith-concept-v02.png`：使用内置 image_gen 生成独立修订概念板并复制至项目；旧版概念图保留用于其他三种建筑参考。
- 新增 `project_spec/monolith-concept-v02.prompt.txt`：保存完整生成提示词。
- 修改 `AI usage declaration.md` 记录本次工作。已目视检查图像，标注图像比例误差；未创建或测试 3D 模型，未读取或修改 design diary。

### 2026-11-08：纠正巨碑参考的含义

- 用户澄清：巨碑应与世界其他元素格格不入，整体是肃杀气氛的立方体，不应照抄 2001 巨碑，也不必保持 1:4:9。
- 修改 `project_spec/建筑建模说明_v01.md`：撤销 v02 的细长碑和比例要求，采用冷硬立方体方案；3D 边长仅为 AI 建议的灰模起点。同步修订尺寸、碰撞、镜头说明、参考说明及文件名。
- 使用内置 image_gen 编辑前一版概念板，新增 `project_spec/monolith-concept-v03.png` 与完整提示词 `project_spec/monolith-concept-v03.prompt.txt`。旧图保留，文档明确其被替代。
- 更新 `AI usage declaration.md` 记录本次修改。已目视检查概念图，未创建 3D 模型或进行游戏运行测试；未读取或修改 design diary。

### 2026-11-08：补充纹理并恢复供能功能的视觉表达

- 用户要求：巨碑不能只是光秃立方体，需要纹理；作为供能巨碑，外观必须体现供能。
- 使用内置 image_gen 先编辑生成石纹刻槽中间稿 v04；用户补充功能要求后继续编辑为 v05，加入顶部核心、连续导能槽、低位供能口和能量传递示意。v04 未采用，未复制到项目。
- 新增 `project_spec/monolith-concept-v05.png` 和完整最终提示词 `project_spec/monolith-concept-v05.prompt.txt`。
- 修改 `project_spec/建筑建模说明_v01.md`：撤销无纹理、无核心、无出口及单一网格的限制，补充石质贴图、几何刻槽、独立发光部件、尺寸、UV、能量流动和模型检查要求。
- 修改 `AI usage declaration.md` 记录此次修订。已目视检查概念图，并标明视图之间的刻槽差异及浅嵌尺寸依据；尚未创建模型、材质或运行游戏验证。未读取或修改 design diary。

### 2026-11-08：打包建模资产

- 用户要求：将建模所需样图与提示词打包为 ZIP。
- 新增 `project_spec/建模交付包说明.md`：明确有效版本、阅读顺序、建模交付要求，以及四建筑合图第 01 栏作废的说明。
- 新增 `project_spec/当前建筑建模提示词.txt`：按当前方案整理四类建筑的独立建模提示词，避免原始图片编辑提示词依赖此前对话。
- 新增根目录 `Prototype_A_Modeling_Assets_2026-11-08.zip`：包含两张有效参考图片、两个原始图片提示词、当前建模提示词、建模说明、交付说明及本 AI 使用声明。未包含废止的独立巨碑 v02、v03 图像或 design diary。
- 更新 `AI usage declaration.md` 记录打包工作。ZIP 创建后检查条目、解压读取和源文件字节一致性；未生成新的图片或 3D 模型。
